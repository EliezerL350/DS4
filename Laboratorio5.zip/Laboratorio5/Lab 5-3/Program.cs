﻿string[] frutas = { "manzana", "plátano", "naranja" };

foreach (string fruta in frutas)
{
    Console.WriteLine(fruta);
}