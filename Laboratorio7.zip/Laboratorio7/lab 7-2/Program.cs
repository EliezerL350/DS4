﻿using lab_7_2;

internal class Program
{
    static void Main(string[] args)
    {
        JuegoDeDados j = new JuegoDeDados();
        j.Jugar();
    }
}